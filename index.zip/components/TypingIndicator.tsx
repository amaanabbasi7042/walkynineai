
import React from 'react';
import { BotIcon } from './Icons';

const TypingIndicator: React.FC = () => {
  return (
    <div className="flex items-start gap-4 max-w-4xl mx-auto">
      <div className="w-8 h-8 flex-shrink-0 text-white mt-1">
        <BotIcon />
      </div>
      <div className="p-4 rounded-2xl rounded-bl-none bg-neutral flex items-center space-x-2">
        <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce [animation-delay:-0.3s]"></span>
        <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce [animation-delay:-0.15s]"></span>
        <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></span>
      </div>
    </div>
  );
};

export default TypingIndicator;
