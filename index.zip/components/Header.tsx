
import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="bg-neutral shadow-md p-4 flex items-center justify-center">
      <h1 className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-accent to-info">
        WalkyNine AI
      </h1>
    </header>
  );
};

export default Header;
