
import React, { ReactElement } from 'react';
import { Message, Role } from '../types';
import { BotIcon, UserIcon, ErrorIcon } from './Icons';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import CopyButton from './CopyButton';

interface ChatMessageProps {
  message: Message;
}

const ChatMessage: React.FC<ChatMessageProps> = ({ message }) => {
  const isUserModel = message.role === Role.Model;
  const isUser = message.role === Role.User;
  const isError = message.role === Role.Error;

  const wrapperClasses = `flex items-start gap-4 max-w-4xl mx-auto ${
    isUser ? 'flex-row-reverse' : ''
  }`;
  
  const bubbleClasses = `p-4 rounded-2xl max-w-2xl prose prose-invert prose-p:my-0 prose-pre:bg-transparent prose-pre:p-0 prose-code:bg-neutral-900 prose-code:p-1 prose-code:rounded-md prose-code:font-mono prose-code:text-sm ${
    isUserModel ? 'bg-neutral rounded-bl-none' : ''
  } ${isUser ? 'bg-primary rounded-br-none' : ''} ${
    isError ? 'bg-red-800/50 border border-error rounded-br-none' : ''
  }`;

  const icon = isUser ? (
    <UserIcon />
  ) : isError ? (
    <ErrorIcon />
  ) : (
    <BotIcon />
  );

  return (
    <div className={wrapperClasses}>
      <div className="w-8 h-8 flex-shrink-0 text-white mt-1">{icon}</div>
      <div className={bubbleClasses}>
        {isUserModel ? (
          <ReactMarkdown
            remarkPlugins={[remarkGfm]}
            components={{
              pre: ({ children }) => {
                const codeElement = React.Children.toArray(children)[0] as ReactElement;
                if (!codeElement) return null;
                
                const codeString = String(codeElement.props.children).trim();
                const language = codeElement.props.className?.replace('language-', '') || '';

                return (
                  <div className="relative bg-[#0d1117] rounded-lg my-2 font-mono">
                     <div className="flex items-center justify-between px-3 py-1 bg-neutral-800/70 rounded-t-lg text-xs">
                      <span className="text-gray-400 font-sans">{language}</span>
                      <CopyButton textToCopy={codeString} />
                    </div>
                    <pre className="p-4 overflow-x-auto">
                      {children}
                    </pre>
                  </div>
                );
              },
            }}
          >
            {message.content}
          </ReactMarkdown>
        ) : (
          <p className="whitespace-pre-wrap">{message.content}</p>
        )}
      </div>
    </div>
  );
};

export default ChatMessage;
