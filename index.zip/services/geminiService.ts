
import { GoogleGenAI, Chat } from '@google/genai';

class GeminiService {
  private ai: GoogleGenAI;

  constructor() {
    if (!process.env.API_KEY) {
        console.error("API_KEY environment variable not set.");
        throw new Error("API_KEY environment variable not set.");
    }
    this.ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  }

  public startChat(): Chat {
    return this.ai.chats.create({
      model: 'gemini-2.5-flash-preview-04-17',
      config: {
        systemInstruction: 'You are WalkyNine, a helpful and friendly AI assistant. Your responses should be informative, well-structured, and engaging. Use markdown for formatting when appropriate.',
      },
    });
  }
}

export const geminiService = new GeminiService();
